#!/bin/bash
rm -rf "$HOME/Library/Application Support/SuperCollider/Extensions/HPfilterUGens"
echo "HPfilterUGens desinstalle."
