#!/bin/bash
rm -rf "$HOME/Library/Application Support/SuperCollider/Extensions/HPkohonen"
echo "HPkohonen desinstalle. Relancez SuperCollider."
