#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SC_SRC="$HOME/Developer/supercollider-3.14.1"
BUILD="$ROOT/build-universal"
DEST="$HOME/Library/Application Support/SuperCollider/Extensions/HPkohonen"
die(){ echo "[ERREUR] $*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || die "macOS requis."
xcode-select -p >/dev/null 2>&1 || { xcode-select --install || true; die "Terminez l'installation des outils Apple puis relancez."; }
if [[ -x /opt/homebrew/bin/brew ]]; then eval "$(/opt/homebrew/bin/brew shellenv)"; fi
command -v brew >/dev/null 2>&1 || die "Homebrew absent. Installez-le depuis https://brew.sh"
brew list cmake >/dev/null 2>&1 || brew install cmake
CMAKE="$(brew --prefix cmake)/bin/cmake"
[[ -x "$CMAKE" ]] || die "CMake Homebrew introuvable."
if [[ ! -f "$SC_SRC/include/plugin_interface/SC_PlugIn.h" ]]; then
  mkdir -p "$(dirname "$SC_SRC")"
  git clone --recursive --depth 1 --branch Version-3.14.1 https://github.com/supercollider/supercollider.git "$SC_SRC"
fi
rm -rf "$BUILD"; mkdir -p "$BUILD"; cd "$BUILD"
"$CMAKE" "$ROOT" \
  "-DSC_PATH=$SC_SRC" \
  "-DCMAKE_BUILD_TYPE=Release" \
  "-DCMAKE_OSX_ARCHITECTURES=x86_64;arm64" \
  "-DCMAKE_OSX_DEPLOYMENT_TARGET=11.0"
"$CMAKE" --build . --config Release --parallel "$(sysctl -n hw.logicalcpu 2>/dev/null || echo 2)"
[[ -f "$BUILD/HPkohonen.scx" ]] || die "HPkohonen.scx n'a pas ete genere."
ARCHS="$(lipo -archs "$BUILD/HPkohonen.scx")"
[[ " $ARCHS " == *" x86_64 "* && " $ARCHS " == *" arm64 "* ]] || die "Binaire non universel : $ARCHS"
[[ ! -d "$DEST" ]] || mv "$DEST" "${DEST}.backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DEST/Classes" "$DEST/tests" "$DEST/HelpSource/Classes"
cp "$BUILD/HPkohonen.scx" "$DEST/"
cp "$ROOT/Classes/"*.sc "$DEST/Classes/"
cp "$ROOT/tests/"*.scd "$DEST/tests/"
cp "$ROOT/HelpSource/Classes/"*.schelp "$DEST/HelpSource/Classes/"
codesign --force --sign - "$DEST/HPkohonen.scx"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true
echo "[OK] HPkohonen installe. Architectures : $ARCHS"
echo "Quittez et relancez SuperCollider, puis Language > Recompile Class Library."
