HPkohonen - installateur universel macOS

Cible : SuperCollider 3.14.1, macOS 11+, Intel x86_64 et Apple Silicon arm64.
Lancez Installer-HPkohonen.command. Le script compile, verifie, signe localement et installe le plugin.

Corrections appliquees : tailles des tableaux pour les indices 0..127 et 0..512, boucles d'apprentissage qui ne s'executaient pas, inclusion des en-tetes C++ requis.
