#!/bin/bash
rm -rf "$HOME/Library/Application Support/SuperCollider/Extensions/HPUGens"
echo "HPUGens desinstalle."
