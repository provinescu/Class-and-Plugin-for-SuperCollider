#!/bin/bash
rm -rf "$HOME/Library/Application Support/SuperCollider/Extensions/HPFFT_UGens"
echo "HPFFT_UGens desinstalle."
