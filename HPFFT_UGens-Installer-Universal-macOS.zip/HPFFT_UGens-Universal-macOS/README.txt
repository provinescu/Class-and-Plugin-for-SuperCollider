HPFFT_UGens - paquet universel macOS Intel + Apple Silicon

Double-cliquez Installer-HPFFT_UGens.command ou lancez-le depuis Terminal.
Cible: SuperCollider 3.14.1, macOS 11+.
Le .scx est compile localement en x86_64 + arm64, verifie avec lipo, signe localement et installe dans Extensions.
