#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SC_SRC="$HOME/Developer/supercollider-3.14.1"
BUILD="$ROOT/build-universal"
DEST="$HOME/Library/Application Support/SuperCollider/Extensions/HPFFT_UGens"
die(){ echo "[ERREUR] $*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || die "macOS requis."
xcode-select -p >/dev/null 2>&1 || { xcode-select --install || true; die "Installez les outils Apple puis relancez."; }
if [[ -x /opt/homebrew/bin/brew ]]; then eval "$(/opt/homebrew/bin/brew shellenv)"; fi
command -v brew >/dev/null 2>&1 || die "Homebrew absent. Installez-le depuis https://brew.sh"
brew list cmake >/dev/null 2>&1 || brew install cmake
CMAKE="$(brew --prefix cmake)/bin/cmake"
if [[ ! -f "$SC_SRC/include/plugin_interface/SC_PlugIn.h" ]]; then
 mkdir -p "$(dirname "$SC_SRC")"
 git clone --recursive --depth 1 --branch Version-3.14.1 https://github.com/supercollider/supercollider.git "$SC_SRC"
fi
rm -rf "$BUILD"; mkdir -p "$BUILD"; cd "$BUILD"
"$CMAKE" "$ROOT" "-DSC_PATH=$SC_SRC" "-DCMAKE_BUILD_TYPE=Release" "-DCMAKE_OSX_ARCHITECTURES=x86_64;arm64" "-DCMAKE_OSX_DEPLOYMENT_TARGET=11.0"
"$CMAKE" --build . --config Release --parallel "$(sysctl -n hw.logicalcpu 2>/dev/null || echo 2)"
[[ -f "$BUILD/HPFFT_UGens.scx" ]] || die "Le fichier .scx n'a pas ete produit."
ARCHS="$(lipo -archs "$BUILD/HPFFT_UGens.scx")"
[[ " $ARCHS " == *" x86_64 "* && " $ARCHS " == *" arm64 "* ]] || die "Binaire non universel: $ARCHS"
[[ ! -d "$DEST" ]] || mv "$DEST" "${DEST}.backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DEST/Classes" "$DEST/tests"
cp "$BUILD/HPFFT_UGens.scx" "$DEST/"
cp "$ROOT/Classes/"*.sc "$DEST/Classes/" 2>/dev/null || true
cp "$ROOT/tests/"*.scd "$DEST/tests/" 2>/dev/null || true
codesign --force --sign - "$DEST/HPFFT_UGens.scx"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true
echo "[OK] HPFFT_UGens installe. Architectures: $ARCHS"
echo "Quittez et relancez SuperCollider, puis recompilez la bibliotheque de classes."
