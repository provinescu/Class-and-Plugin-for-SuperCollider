#!/bin/bash
set -Eeuo pipefail
IFS=$'\n\t'
ROOT="$(cd "$(dirname "$0")" && pwd)"
SC_VERSION="Version-3.14.1"
SC_SRC="$HOME/Developer/supercollider-3.14.1"
BUILD="$ROOT/build-universal"
DEST="$HOME/Library/Application Support/SuperCollider/Extensions/HPPV_UGens"
log(){ printf '\n[INFO] %s\n' "$*"; }
die(){ printf '\n[ERREUR] %s\n' "$*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || die "Ce programme exige macOS."
xcode-select -p >/dev/null 2>&1 || { xcode-select --install || true; die "Terminez l'installation des outils Apple puis relancez."; }
if [[ -x /opt/homebrew/bin/brew ]]; then eval "$(/opt/homebrew/bin/brew shellenv)"; fi
if ! command -v brew >/dev/null 2>&1; then
  die "Homebrew est absent. Installez-le avec la commande officielle de https://brew.sh puis relancez."
fi
if ! command -v cmake >/dev/null 2>&1 || [[ "$(cmake --version | awk 'NR==1{print $3}' | cut -d. -f1)" -lt 3 ]]; then
  brew install cmake
fi
CMAKE="$(brew --prefix cmake)/bin/cmake"
[[ -x "$CMAKE" ]] || { brew install cmake; CMAKE="$(brew --prefix cmake)/bin/cmake"; }
log "CMake : $($CMAKE --version | head -n1)"
if [[ ! -f "$SC_SRC/include/plugin_interface/SC_PlugIn.h" ]]; then
  mkdir -p "$(dirname "$SC_SRC")"
  git clone --recursive --depth 1 --branch "$SC_VERSION" https://github.com/supercollider/supercollider.git "$SC_SRC"
fi
rm -rf "$BUILD" && mkdir -p "$BUILD"
cd "$BUILD"
"$CMAKE" "$ROOT" \
  "-DSC_PATH=$SC_SRC" \
  "-DCMAKE_BUILD_TYPE=Release" \
  "-DCMAKE_OSX_ARCHITECTURES=x86_64;arm64" \
  "-DCMAKE_OSX_DEPLOYMENT_TARGET=11.0"
"$CMAKE" --build . --config Release --parallel "$(sysctl -n hw.logicalcpu 2>/dev/null || echo 2)"
[[ -f "$BUILD/HPPV_UGens.scx" ]] || die "HPPV_UGens.scx n'a pas ete genere."
ARCHS="$(lipo -archs "$BUILD/HPPV_UGens.scx")"
[[ " $ARCHS " == *" arm64 "* && " $ARCHS " == *" x86_64 "* ]] || die "Binaire non universel : $ARCHS"
BACKUP=""
if [[ -d "$DEST" ]]; then BACKUP="${DEST}.backup-$(date +%Y%m%d-%H%M%S)"; mv "$DEST" "$BACKUP"; fi
mkdir -p "$DEST/Classes" "$DEST/HelpSource/Classes" "$DEST/tests"
cp "$BUILD/HPPV_UGens.scx" "$DEST/"
cp "$ROOT/Classes/"*.sc "$DEST/Classes/"
cp "$ROOT/HelpSource/Classes/"*.schelp "$DEST/HelpSource/Classes/" 2>/dev/null || true
cp "$ROOT/tests/"*.scd "$DEST/tests/" 2>/dev/null || true
codesign --force --sign - "$DEST/HPPV_UGens.scx"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true
printf '\n[OK] Installation terminee. Architectures : %s\n' "$ARCHS"
printf 'Dossier : %s\n' "$DEST"
printf 'Quittez et relancez SuperCollider, puis recompilez la bibliotheque de classes.\n'
