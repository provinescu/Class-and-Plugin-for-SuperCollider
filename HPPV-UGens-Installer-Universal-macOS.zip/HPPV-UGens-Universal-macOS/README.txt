HPPV_UGens - paquet universel macOS

1. Double-cliquez Installer-HPPV-UGens.command.
2. Si macOS bloque le fichier: clic droit > Ouvrir.
3. Le programme compile un seul HPPV_UGens.scx pour Intel x86_64 et Apple Silicon arm64.
4. Quittez et relancez SuperCollider, puis Language > Recompile Class Library.

Cible: SuperCollider 3.14.1, macOS 11 ou plus recent.
