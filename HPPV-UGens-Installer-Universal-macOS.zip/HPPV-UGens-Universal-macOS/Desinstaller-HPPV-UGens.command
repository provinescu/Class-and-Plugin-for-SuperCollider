#!/bin/bash
set -e
DEST="$HOME/Library/Application Support/SuperCollider/Extensions/HPPV_UGens"
rm -rf "$DEST"
echo "HPPV_UGens a ete desinstalle. Relancez SuperCollider."
