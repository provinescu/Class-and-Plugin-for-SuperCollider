# HPdelayUGens universal macOS

Projet de compilation de `HPdelayUGens.scx` pour Intel `x86_64` et Apple Silicon `arm64`.

## Installation automatique

1. Ouvrez Terminal.
2. Placez-vous dans ce dossier.
3. Exécutez :

```bash
chmod +x installer-HPdelayUGens-universal.command
./installer-HPdelayUGens-universal.command
```

Le script télécharge les sources de SuperCollider 3.14.1 si nécessaire, compile le plugin universel, vérifie les deux architectures et installe le plugin dans le dossier utilisateur de SuperCollider.

## Après installation

Quittez complètement SuperCollider, relancez-le, recompilez la bibliothèque de classes, puis exécutez :

```supercollider
HPplayBuf.dumpInterface;
HPbufRd.dumpInterface;
HPtGrains.dumpInterface;
s.reboot;
```

## Remarque

Ce projet contient le fichier C++ fourni par l'auteur. Si Apple Clang signale des incompatibilités liées à l'ancienne API de SuperCollider, consultez le journal `install-HPdelayUGens.log`.
