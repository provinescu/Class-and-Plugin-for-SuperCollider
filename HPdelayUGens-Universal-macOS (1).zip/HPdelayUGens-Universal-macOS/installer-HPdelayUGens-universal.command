#!/bin/bash
# HPdelayUGens - compilation et installation universelles macOS
# Compatible Intel x86_64 et Apple Silicon arm64

set -Eeuo pipefail
IFS=$'\n\t'

PLUGIN_NAME="HPdelayUGens"
SC_VERSION="${SC_VERSION:-Version-3.14.1}"
MIN_MACOS="${MIN_MACOS:-11.0}"
PROJECT_DIR="${PROJECT_DIR:-$(cd "$(dirname "$0")" && pwd)}"
BUILD_DIR="${BUILD_DIR:-$PROJECT_DIR/build-universal}"
SC_SOURCE_DIR="${SC_SOURCE_DIR:-$HOME/Developer/supercollider-${SC_VERSION#Version-}}"
EXTENSIONS_ROOT="${EXTENSIONS_ROOT:-$HOME/Library/Application Support/SuperCollider/Extensions}"
INSTALL_DIR="$EXTENSIONS_ROOT/$PLUGIN_NAME"
SCX_SOURCE="$BUILD_DIR/$PLUGIN_NAME.scx"
LOG_FILE="$PROJECT_DIR/install-${PLUGIN_NAME}.log"
BACKUP_DIR=""
CMAKE_BIN=""

exec > >(tee "$LOG_FILE") 2>&1

info()  { printf '\n\033[1;34m[INFO]\033[0m %s\n' "$*"; }
ok()    { printf '\033[1;32m[OK]\033[0m %s\n' "$*"; }
warn()  { printf '\033[1;33m[ATTENTION]\033[0m %s\n' "$*"; }
fatal() { printf '\033[1;31m[ERREUR]\033[0m %s\n' "$*" >&2; exit 1; }

on_error() {
    local line="$1"
    printf '\n\033[1;31m[ERREUR]\033[0m Echec a la ligne %s.\n' "$line" >&2
    printf 'Consultez le journal : %s\n' "$LOG_FILE" >&2
    if [[ -n "$BACKUP_DIR" && -d "$BACKUP_DIR" && ! -d "$INSTALL_DIR" ]]; then
        warn "Restauration de l'ancienne installation."
        mv "$BACKUP_DIR" "$INSTALL_DIR" || true
    fi
}
trap 'on_error $LINENO' ERR

require_macos() {
    [[ "$(uname -s)" == "Darwin" ]] || fatal "Ce script doit etre execute sous macOS."
    command -v sw_vers >/dev/null || fatal "La commande sw_vers est introuvable."
    info "macOS $(sw_vers -productVersion), machine $(uname -m)"
}

check_project() {
    [[ -f "$PROJECT_DIR/CMakeLists.txt" ]] || fatal "CMakeLists.txt absent de $PROJECT_DIR"
    [[ -f "$PROJECT_DIR/plugins/HPdelayUGens.cpp" ]] || fatal "plugins/HPdelayUGens.cpp absent. Placez ce script a la racine du projet."
    [[ -d "$PROJECT_DIR/Classes" ]] || fatal "Le dossier Classes est absent."
}

install_apple_tools() {
    if ! xcode-select -p >/dev/null 2>&1; then
        info "Ouverture de l'installateur des outils Apple..."
        xcode-select --install || true
        fatal "Terminez l'installation des outils Apple, puis relancez ce script."
    fi
    command -v clang >/dev/null || fatal "Apple Clang est introuvable."
    command -v lipo >/dev/null || fatal "L'outil Apple lipo est introuvable."
    ok "Outils de compilation Apple detectes."
}

ensure_command() {
    local cmd="$1"
    if command -v "$cmd" >/dev/null 2>&1; then return 0; fi
    command -v brew >/dev/null 2>&1 || fatal "$cmd est absent et Homebrew n'est pas installe. Installez Homebrew, puis relancez le script."
    info "Installation de $cmd avec Homebrew..."
    brew install "$cmd"
}

version_ge() {
    # Retourne vrai si $1 est superieur ou egal a $2.
    [[ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n 1)" == "$2" ]]
}

select_modern_cmake() {
    local current=""
    local brew_cmake=""

    if command -v cmake >/dev/null 2>&1; then
        current="$(cmake --version | awk 'NR==1 {print $3}')"
        info "CMake actuellement trouve : $(command -v cmake), version $current"
        if version_ge "$current" "3.16.0"; then
            CMAKE_BIN="$(command -v cmake)"
            ok "Version de CMake suffisante."
            return
        fi
        warn "CMake $current est trop ancien. Version minimale requise : 3.16."
    fi

    if ! command -v brew >/dev/null 2>&1; then
        if [[ -x /opt/homebrew/bin/brew ]]; then
            eval "$(/opt/homebrew/bin/brew shellenv)"
        elif [[ -x /usr/local/bin/brew ]]; then
            eval "$(/usr/local/bin/brew shellenv)"
        else
            fatal "Homebrew est absent. Installez-le depuis https://brew.sh puis relancez le script."
        fi
    fi

    info "Installation ou mise a jour de CMake avec Homebrew..."
    brew list cmake >/dev/null 2>&1 && brew upgrade cmake || brew install cmake
    brew_cmake="$(brew --prefix cmake)/bin/cmake"
    [[ -x "$brew_cmake" ]] || fatal "CMake Homebrew introuvable apres installation : $brew_cmake"
    current="$($brew_cmake --version | awk 'NR==1 {print $3}')"
    version_ge "$current" "3.16.0" || fatal "La version Homebrew de CMake reste trop ancienne : $current"
    CMAKE_BIN="$brew_cmake"
    ok "CMake selectionne : $CMAKE_BIN, version $current"
}

fetch_sc_sources() {
    if [[ -f "$SC_SOURCE_DIR/include/plugin_interface/SC_PlugIn.h" ]]; then
        ok "Sources SuperCollider detectees : $SC_SOURCE_DIR"
        return
    fi
    mkdir -p "$(dirname "$SC_SOURCE_DIR")"
    if [[ -e "$SC_SOURCE_DIR" ]]; then
        fatal "$SC_SOURCE_DIR existe mais ne contient pas SC_PlugIn.h. Supprimez-le ou definissez SC_SOURCE_DIR."
    fi
    info "Telechargement des sources SuperCollider $SC_VERSION..."
    git clone --recursive --depth 1 --branch "$SC_VERSION" \
        https://github.com/supercollider/supercollider.git "$SC_SOURCE_DIR"
    [[ -f "$SC_SOURCE_DIR/include/plugin_interface/SC_PlugIn.h" ]] || fatal "SC_PlugIn.h reste introuvable."
}

build_plugin() {
    info "Nettoyage de l'ancienne compilation..."
    rm -rf "$BUILD_DIR"

    info "Configuration universelle x86_64 + arm64..."
    info "Source du projet : $PROJECT_DIR"
    info "Dossier de build : $BUILD_DIR"
    [[ -f "$PROJECT_DIR/CMakeLists.txt" ]] || fatal "CMakeLists.txt introuvable dans $PROJECT_DIR"
    mkdir -p "$BUILD_DIR"
    (
        cd "$BUILD_DIR"
        "$CMAKE_BIN" "$PROJECT_DIR" \
            "-DSC_PATH=$SC_SOURCE_DIR" \
            "-DCMAKE_BUILD_TYPE=Release" \
            "-DCMAKE_OSX_ARCHITECTURES=x86_64;arm64" \
            "-DCMAKE_OSX_DEPLOYMENT_TARGET=$MIN_MACOS"
    )

    info "Compilation..."
    (
        cd "$BUILD_DIR"
        "$CMAKE_BIN" --build . --config Release --parallel "$(sysctl -n hw.logicalcpu 2>/dev/null || echo 2)"
    )
    [[ -f "$SCX_SOURCE" ]] || fatal "Le fichier $SCX_SOURCE n'a pas ete produit."
}

verify_binary() {
    info "Verification du binaire universel..."
    local archs
    archs="$(lipo -archs "$SCX_SOURCE")"
    printf 'Architectures detectees : %s\n' "$archs"
    [[ " $archs " == *" x86_64 "* ]] || fatal "Architecture x86_64 absente."
    [[ " $archs " == *" arm64 "* ]] || fatal "Architecture arm64 absente."
    file "$SCX_SOURCE"
    ok "Le .scx contient Intel x86_64 et Apple Silicon arm64."
}

install_plugin() {
    info "Installation dans : $INSTALL_DIR"
    mkdir -p "$EXTENSIONS_ROOT"

    if [[ -d "$INSTALL_DIR" ]]; then
        BACKUP_DIR="${INSTALL_DIR}.backup-$(date +%Y%m%d-%H%M%S)"
        mv "$INSTALL_DIR" "$BACKUP_DIR"
        info "Ancienne installation sauvegardee : $BACKUP_DIR"
    fi

    mkdir -p "$INSTALL_DIR/Classes"
    cp "$SCX_SOURCE" "$INSTALL_DIR/$PLUGIN_NAME.scx"
    find "$PROJECT_DIR/Classes" -maxdepth 1 -type f -name '*.sc' -exec cp {} "$INSTALL_DIR/Classes/" \;

    if [[ -d "$PROJECT_DIR/HelpSource" ]]; then
        cp -R "$PROJECT_DIR/HelpSource" "$INSTALL_DIR/HelpSource"
    fi
    if [[ -d "$PROJECT_DIR/tests" ]]; then
        cp -R "$PROJECT_DIR/tests" "$INSTALL_DIR/tests"
    fi

    # Signature ad hoc locale. Elle facilite le chargement sans constituer une notarisation.
    codesign --force --sign - "$INSTALL_DIR/$PLUGIN_NAME.scx"
    xattr -dr com.apple.quarantine "$INSTALL_DIR" 2>/dev/null || true

    lipo -info "$INSTALL_DIR/$PLUGIN_NAME.scx"
    codesign --verify --verbose=2 "$INSTALL_DIR/$PLUGIN_NAME.scx"
    ok "Plugin installe et verifie."
}

print_next_steps() {
    cat <<EOF

============================================================
INSTALLATION TERMINEE
============================================================

Plugin :
  $INSTALL_DIR/$PLUGIN_NAME.scx

Journal :
  $LOG_FILE

Etapes dans SuperCollider :
  1. Quittez completement SuperCollider avec Cmd+Q s'il est ouvert.
  2. Relancez SuperCollider.
  3. Choisissez Language > Recompile Class Library.
  4. Executez :

     HPplayBuf.dumpInterface;
     HPbufRd.dumpInterface;
     HPtGrains.dumpInterface;
     s.reboot;

  5. Lancez ensuite le fichier tests/smoke-test.scd s'il est installe.

Pour desinstaller :
  rm -rf "$INSTALL_DIR"

Pour cibler une autre version de SuperCollider :
  SC_VERSION=Version-3.14.0 "$0"

Pour utiliser des sources deja telechargees :
  SC_SOURCE_DIR="/chemin/vers/supercollider" "$0"

EOF
}

main() {
    require_macos
    check_project
    install_apple_tools
    ensure_command git
    select_modern_cmake
    fetch_sc_sources
    build_plugin
    verify_binary
    install_plugin
    print_next_steps
}

main "$@"
